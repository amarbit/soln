
import cv2
import json
import os
import time
import sqlite3
from datetime import datetime
import threading

# Load camera configurations
with open("camera.json", "r") as f:
    cameras = json.load(f)["cameras"]

# Ensure output directories exist
os.makedirs("captured_images", exist_ok=True)

# SQLite Database Setup
db_file = "events.db"

def setup_database():
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cameraId TEXT,
            timestamp TEXT,
            event TEXT,
            imagePath TEXT
        )
    """)
    conn.commit()
    conn.close()

setup_database()

# Dummy model function (Replace with actual inference logic)
def process_image(image_path):
    return "Motion Detected"  # Example event

# Function to capture images
def capture_images(camera):
    while True:
        cap = cv2.VideoCapture(camera["rtspUrl"])
        if not cap.isOpened():
            print(f"Error: Cannot open stream for {camera['cameraId']}")
            time.sleep(camera["readingInterval"])
            continue

        ret, frame = cap.read()
        cap.release()

        if ret:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_name = f"{camera['cameraId']}_{timestamp}.jpg"
            image_path = os.path.join("captured_images", image_name)
            cv2.imwrite(image_path, frame)

            # Run model inference
            event = process_image(image_path)

            # Log event to database
            conn = sqlite3.connect(db_file)
            c = conn.cursor()
            c.execute("INSERT INTO events (cameraId, timestamp, event, imagePath) VALUES (?, ?, ?, ?)",
                      (camera["cameraId"], timestamp, event, image_path))
            conn.commit()
            conn.close()

            print(f"Logged: {event} from {camera['cameraId']}")

        time.sleep(camera["readingInterval"])

# Start capture threads
for cam in cameras:
    threading.Thread(target=capture_images, args=(cam,), daemon=True).start()

def capture_images(camera):
    while True:
        # Open and close VideoCapture each time to get the latest frame
        cap = cv2.VideoCapture(camera["rtspUrl"])
        if not cap.isOpened():
            print(f"Error: Cannot open stream for {camera['cameraId']}")
            time.sleep(camera["readingInterval"])
            continue  # Skip this cycle and retry

        ret, frame = cap.read()
        cap.release()  # Close capture after reading

        if ret:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            image_name = f"{camera['cameraId']}_{timestamp}.jpg"
            image_path = os.path.join("captured_images", image_name)
            cv2.imwrite(image_path, frame)

            # Run model inference (replace with actual inference logic)
            event = process_image(image_path)

            # Log event to database
            conn = sqlite3.connect(db_file)
            c = conn.cursor()
            c.execute("INSERT INTO events (cameraId, timestamp, event, imagePath) VALUES (?, ?, ?, ?)",
                      (camera["cameraId"], timestamp, event, image_path))
            conn.commit()
            conn.close()

            print(f"Logged: {event} from {camera['cameraId']}")

        # Sleep for interval and repeat
        time.sleep(camera["readingInterval"])
