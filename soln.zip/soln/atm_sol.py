import streamlit as st
import json
import cv2
import numpy as np
import torch
import os
import shutil
import pandas as pd
import zipfile
from io import BytesIO
import plotly.express as px
from PIL import Image
from ultralytics import YOLO
from datetime import datetime
import sqlite3
import matplotlib.pyplot as plt
import time
import warnings
warnings.filterwarnings("ignore")
# st.set_option('deprecation.showPyplotGlobalUse', False)
counter = 1
# Load camera configurations
with open("camera.json", "r") as f:
    cameras = json.load(f)["cameras"]

# Ensure output directories exist
os.makedirs(os.path.join(os.getcwd(),"captured_images"), exist_ok=True)

# SQLite Database Setup
db_file = "events.db"

def setup_database():
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cameraId TEXT,
            timestamp TEXT,
            event TEXT,
            imagePath TEXT
        )
    """)
    conn.commit()
    conn.close()

setup_database()

# Load model
@st.cache_resource()
def load_model():
    model = YOLO("best.pt")
    model.imgsz = (640, 640)
    return model

model = load_model()

# Function to perform inference

def predict(chosen_model, img, classes=[], conf=0.3):
    if classes:
        results = chosen_model.predict(img,imgsz=(640, 640),classes=classes, conf=conf)
    else:
        results = chosen_model.predict(img,imgsz=(640, 640), conf=conf)

    return results


def predict_and_detect(chosen_model, img, classes=[], conf=0.5, rectangle_thickness=2, text_thickness=1):
    results = predict(chosen_model, img, classes, conf=conf)
    for result in results:
        for box in result.boxes:
            cv2.rectangle(img, (int(box.xyxy[0][0]), int(box.xyxy[0][1])),
                          (int(box.xyxy[0][2]), int(box.xyxy[0][3])), (255, 0, 0), rectangle_thickness)
            cv2.putText(img, f"{result.names[int(box.cls[0])]}",
                        (int(box.xyxy[0][0]), int(box.xyxy[0][1]) - 10),
                        cv2.FONT_HERSHEY_PLAIN, 1, (255, 0, 0), text_thickness)
    return img, results

def infer_image(image):
    result_img,  results = predict_and_detect(model, image, classes=[], conf=0.5)
    return result_img,results

def log_to_db(cameraId,event,imagepath):
    # Log event to database
    timestamp = datetime.now().strftime("%d-%m-%Y:%H:%M:%S")
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("INSERT INTO events (cameraId, timestamp, event, imagePath) VALUES (?, ?, ?, ?)",
                (cameraId, timestamp, event, imagepath))
    conn.commit()
    conn.close()
def save_image_and_event(image,cameraid,event_result):
    global counter
    timestamp = datetime.now().strftime("%d%m%Y_%H%M%S")
    image_name = f"{cameraid}_{timestamp}_{str(counter)}.jpg"
    image_path = os.path.join(os.getcwd(),"captured_images", image_name)
    
    cv2.imwrite(image_path, image)
    # log to db
    for result in event_result:
            for box in result.boxes:
                log_to_db("Camera 1", f"{result.names[int(box.cls[0])]}",image_path)
    counter = counter + 1
def get_data():
    conn = sqlite3.connect(db_file)  # Change this to your database file
    query = "SELECT cameraId, timestamp, event, imagePath FROM events"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df
def clear_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM camera_events")  # Delete all records
    conn.commit()
    conn.close()

def plot_pie_chart(df, chart_placeholder):
    event_counts = df['event'].value_counts()

    # Create figure
    fig, ax = plt.subplots(figsize=(4, 4))  # Set size for better layout
    ax.pie(event_counts, labels=event_counts.index, autopct='%1.1f%%', colors=plt.cm.Paired.colors)
    ax.set_title("Event Distribution")

    # Update the same chart location
    chart_placeholder.pyplot(fig)


def plot_grid_pie(df,grid_placeholder,chart_placeholder):
    

    # Left Column: Display data grid
    with grid_placeholder:
        # grid_placeholder.subheader("📊 Event Data")
        grid_placeholder.dataframe(df, height=400)

    # Right Column: Display pie chart
    with chart_placeholder:
        # chart_placeholder.subheader("📈 Event Distribution")
        if not df.empty:
            pie_chart = plot_pie_chart(df,chart_placeholder)
        else:
            chart_placeholder.warning("No data available to plot.")

def infer_video(video_path,grid_placeholder,chart_placeholder):
    cap = cv2.VideoCapture(video_path)
    stframe = st.empty()
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        # results = model(frame)
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame, results =infer_image(image_rgb)
        stframe.image(frame, caption="Processed Frame with Bounding Boxes", channels="BGR", use_column_width=True)
        save_image_and_event(frame,"camera1",results)
        df = get_data()
        plot_grid_pie(df,grid_placeholder,chart_placeholder)
        time.sleep(0.3)
    cap.release()

def check_file_type(file_path):
    mime_type= file_path.type

    if mime_type:
        if mime_type.startswith("image"):
            return "Image"
        elif mime_type.startswith("video"):
            return "Video"
    return "Unknown"

def capture_images(camera,grid_placeholder,chart_placeholder):
    stframe = st.empty()
    while True:
        # Open and close VideoCapture each time to get the latest frame
        cap = cv2.VideoCapture(int(camera["rtspUrl"]))
        if not cap.isOpened():
            print(f"Error: Cannot open stream for {camera['cameraId']}")
            time.sleep(camera["readingInterval"])
            continue  # Skip this cycle and retry

        ret, frame = cap.read()
        cap.release()  # Close capture after reading

        if ret:
  

            # Run model inference (replace with actual inference logic)

            image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image_rgb = cv2.resize(image_rgb,(640,640))
            frame, results =infer_image(image_rgb)
            stframe.image(frame, caption="Processed Frame with Bounding Boxes", channels="RGB", use_column_width=True)
            save_image_and_event(frame,camera["cameraId"],results)
            df = get_data()
            plot_grid_pie(df,grid_placeholder,chart_placeholder)
            time.sleep(0.3)

        # Sleep for interval and repeat
        time.sleep(int(camera["readingInterval"]))

if __name__ == "__main__":
    # Sidebar
    try:
        st.sidebar.title("Face Mask and Helmet Detection")
        option = st.sidebar.radio("Choose input type:", ["Image/Video","camera"])

        # Main Area
        st.title("Real-Time Face mask and Helmet Detection")
        upload_file_path = st.file_uploader("Upload an Image", type=["jpg", "png", "jpeg","mp4", "avi", "mov"])
        col1, col2 = st.columns([1.5, 1])  # Grid and Pie Chart layout
        grid_placeholder = col1.empty()   # Placeholder for table
        chart_placeholder = col2.empty()  #
        image_placeholder = st.empty()

        if upload_file_path:
            option = check_file_type(upload_file_path)

        if option == "Image":
            if upload_file_path:
                image = Image.open(upload_file_path)
                image_np = np.array(image)
                img,results = infer_image(image_np)
                image_placeholder.image(img, caption="Detected Objects", use_column_width=True)
                save_image_and_event(img,"camera1",results)
                df = get_data()
                plot_grid_pie(df,grid_placeholder,chart_placeholder)

        if option == "Video":
            if upload_file_path:
                with open("temp_video.mp4", "wb") as f:
                    f.write(upload_file_path.read())
                infer_video("temp_video.mp4",grid_placeholder,chart_placeholder)
        if option == "camera":
            print(cameras[0])
            capture_images(cameras[0],grid_placeholder,chart_placeholder)
    except Exception as e:
          print(f"An error occurred: {e}")


